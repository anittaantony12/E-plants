<html>
<?php
include("prj1.php");
?>
<head></head>
<body>
<table border="1">
<tr>
<td>name</td>
<td>address</td>
<td>phoneno</td>
<td>edit</td>
<td>delete</td>

</tr>
<?php
$s=mysqli_query($con,"select * from student");
while($row=mysqli_fetch_array($s))
{
?>

<tr><td><?php echo $row['name']?></td>
<td><?php echo $row['address']?></td>
<td><?php echo $row['phoneno']?></td>
<td><a href="edit.php?id=<?php echo $row["id"];?>">edit</a></td>
<td><a href="delete.php?id=<?php echo $row["id"];?>">delete</a></td></tr>


<?php
}
?>


</table>
</body>
</html>