<html>
<?php
include("prj1.php");
$id=$_GET['id'];
mysqli_query($con,"delete from student where id='$id'");
header("location:view1.php");
?>
</html>

