<?php
include("prj1.php");
$id=$_GET["id"];
if(isset($_POST["submit"]))
{
	$m=$_POST["name"];
	$n=$_POST["address"];
	$o=$_POST["phno"];
	mysqli_query($con,"UPDATE `student` SET `name`='$m',`address`='$n',`phoneno`='$o' WHERE id='$id'");
	header("Location:view1.php");
}
?>
<html>
<head>
</head>
<body>
<form action="#" method="post">
<table>
<?php
	$id=$_GET["id"];
	$result=mysqli_query($con,"SELECT * FROM `student` WHERE id='$id'");
	while($row=mysqli_fetch_array($result))
	{
?>
	<tr>
		<td>name</td>
		<td><input type="text" name="name" value="<?php echo $row["name"];?> " /></td>
	</tr>
	<tr>
		<td>address</td>
		<td><input type="text" name="address" value="<?php echo $row["address"];?> " /></td>
	</tr>
	<tr>
		<td>phoneno</td>
		<td><input type="text" name="phno" value="<?php echo $row["phoneno"];?> "/></td>
	</tr>
	<tr><td><input type="submit" name="submit" value="edit" /></td></tr>
	<?php
	}
	?>
</body>
</html>