<html>
<?php
include("prj1.php");
if(isset($_POST["submit"]))
{
$m=$_POST["name"];

$n=$_POST["address"];

$o=$_POST["phno"];
mysqli_query($con,"INSERT INTO `student`( `name`, `address`, `phoneno`) VALUES ('$m','$n','$o')");
}
?>
<body>
<form action="#" method="post">
<table>
<tr>
<td>name
</td>
<td><input type="text" name="name" />
</td>
</tr>
<tr>
<td>address
</td>
<td><input type="text" name="address" />
</td>
</tr>
<tr>
<td>phoneno
</td>
<td><input type="text" name="phno" />
</td>
</tr>
<tr>
<td><input type="submit" name="submit"></td></tr>
</table>
</form>
</body>
</html>

