<html>
<?php
include("prj1.php");
?>
<head></head>
<body>
<?php
$s=mysqli_query($con,"select * from student");
?>
<table border="1">
<tr>
<td>name</td>
<td>address</td>
<td>phoneno</td>
<td>edit</td>
<td>delete</td>

</tr>
<?php
while($row=mysqli_fetch_array($s))
{
?>
<tr><td><?php echo $row['name']?></td>
<td><?php echo $row['address']?></td>
<td><?php echo $row['phoneno']?></td></tr>
<?php
}
?>
</table>
</body>
</html>
