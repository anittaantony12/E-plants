import{NgForm} from '@angular/forms';
export class student{
    id:number;
        name:string;
        username:string;
        password:string;
        status:number
    constructor(
        )
    {}
}