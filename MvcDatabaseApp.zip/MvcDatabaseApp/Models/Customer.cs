﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcDatabaseApp.Models
{
    public class Customer
    {
        public int CustomerID { get; set; }
        [Required(ErrorMessage="can't be empty")]
        [Display(Name="name")]
        public string Cname { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "address")]
        public string Caddress { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "email")]
        public string Cemail { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "username")]
        public string Cusername { get; set; }
        [Required(ErrorMessage = "can't be empty")]
        [Display(Name = "password")]
        public string Cpassword { get; set; }

    }
}