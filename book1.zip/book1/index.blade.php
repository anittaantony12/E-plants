<table border="1">
<thead>
<tr>
<th>id</th>

<th>name</th>
<th>age</th>
</tr>
</thead>
<tbody>
@foreach($booksdetails as $book1)
<tr>
<td>{{$book1->id}}</td>
<td>{{$book1->name}}</td>
<td>{{$book1->age}}</td>
<td>
<a href="{{route('book1.edit',$book1->id)}}">
Edit</a>
</td>
<td>
<form action="{{route('book1.destroy',$book1->id)}}" method="post">
@csrf
@method('DELETE')
<button type="submit">Delete</button>
</form>
</td>
</tr>
@endforeach
</tbody>
</table>