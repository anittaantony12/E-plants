<form method="post" action="{{route('book1.update',$books1->id)}}">
@method('PATCH')
@csrf
<div class="form-group">
<label for="name">name:</label>
<input type="text" name="name"  value={{$books1->name}}/>
</div>
<div class="form-group">
<label for="price">age</label>
<input type="text" name="age" value={{$books1->age}} />
</div>
<button type="submit">Update</button>
</form>
