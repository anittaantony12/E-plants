<form method="post" action="{{route('book1.store')}}">
@csrf
name<input type="text" name="name" /><br/>
age<input type="text" name="age" />
<button type="submit">add</button>
</form>

