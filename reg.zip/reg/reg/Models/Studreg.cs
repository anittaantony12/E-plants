﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace reg.Models
{
    public class Studreg
    { 
        [Required(ErrorMessage="Can't be empty")]
        [Display(Name="Student Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Gender")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Address")]
        [DataType(DataType.MultilineText)]
        public string Address { get; set; }

        [Required(ErrorMessage = "Can't be empty")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Course")]
        public course course { get; set; }

        [Required(ErrorMessage = "Can't be empty")]
        [Display(Name = "Username")]
        public string Username { get; set; }
        [Required(ErrorMessage="Can't be empty")]
        [Display(Name="Password")]
        [DataType(DataType.Password)]

        public string Password { get; set; }
        [Required(ErrorMessage="Can't be empty")]
        [Display(Name="Confirm Password")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
        [StringLength(30)]
        [Display(Name="Photo")]
        
        public string PostImage { get; set; }
        [Required(ErrorMessage = "Required")]
        [Display(Name = "                   ")]

        public bool IsCheck { get; set; }
    }
    public enum course
    {
        MCA,
        BCA,
        BTech
    }
    
}
