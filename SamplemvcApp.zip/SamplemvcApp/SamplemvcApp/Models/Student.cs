﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace SamplemvcApp.Models
{
    public class Student
    {
        [Required(ErrorMessage="fill name")]
        [Display(Name="Student Name")]
       // [RegularExpression()]
        public string Sname { get; set; }
        [Required(ErrorMessage="fill address")]
        [Display(Name = "Student Address")]
        [DataType(DataType.MultilineText)]
        public string Saddress { get; set; }
        [Required(ErrorMessage="fill email")]
        [Display(Name = "Student Email")]
        [DataType(DataType.EmailAddress)]

        public string Semail { get; set; }
         [Required(ErrorMessage = "select one item from list")]
         [Display(Name = "Student Course")]
        public string Scourse { get; set; }
    }
    public enum Scourse
    {
        Mca,
        Mtech
    }
}