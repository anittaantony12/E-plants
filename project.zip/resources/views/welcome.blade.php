<!--
	Author: W3layouts
	Author URL: http://w3layouts.com
	License: Creative Commons Attribution 3.0 Unported
	License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>E-plants</title>
	<!-- Meta tag Keywords -->
    <meta name="csrf-token"content="{{csrf_token()}}">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Green Life web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->
	<!-- css files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-css -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-css -->
	<link rel="stylesheet" href="css/font-awesome.css">
	<!-- Font-Awesome-Icons-css -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<!-- Popup css (for Video Popup) -->
	<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="all">
	<!-- Lightbox css (for Projects) -->
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
	<!-- Flexslider css (for Testimonials) -->
	<!-- //css files -->
	<!-- web-fonts -->
	<link href="//fonts.googleapis.com/css?family=Economica:400,400i,700,700i&amp;subset=latin-ext" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Rasa:300,400,500,600,700" rel="stylesheet">
	<!-- //web-fonts -->
</head>

<body>
	<div class="main-agile">
		<!-- banner -->
		<div class="agile-top">
			<div class="col-xs-4 logo">
				<h1>
					<a href="index.html">
						<span>E</span>-plants
				</h1>
			</div>
			<div class="col-xs-6 header-w3l">
				<ul>
					<li>
						<a href="#" data-toggle="modal" data-target="#myModal1">
							<span class="fa fa-unlock-alt" aria-hidden="true"></span> Sign In </a>
					</li>
					<li>
						<a href="#" data-toggle="modal" data-target="#myModal2">
							<span class="fa fa-pencil-square-o" aria-hidden="true"></span> Sign Up </a>
					</li>
				</ul>
			</div>
			<!-- navigation -->
			<div class="col-xs-2 menu">
				<a href="" id="menuToggle">
					<span class="navClosed"></span>
				</a>
				<nav>
					<a href="welcome">Home</a>
					<a href="#about" class="scroll">About Us</a>
					<a href="#services" class="scroll">Services</a>
					<a href="#contact" class="scroll">Contact Us</a>
				</nav>
			</div>
			<!-- //navigation -->
		</div>
	</div>
	<!-- signin Model -->
	<!-- Modal1 -->
	<div class="modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body modal-body-sub_agile">
					<div class="main-mailposi">
						<span class="fa fa-envelope-o" aria-hidden="true"></span>
					</div>
					<div class="modal_body_left modal_body_left1">
						<h3 class="agileinfo_sign">Sign In </h3>
						<p>
							Sign In now, Let's start your Grocery Shopping. Don't have an account?
							<a href="registerme" data-toggle="modal" data-target="#myModal2">
								Sign Up Now</a>
						</p>
						<form action="/loginme" method="post">
							<div class="styled-input agile-styled-input-top">
                         <input type="hidden" name="_token" value="{{csrf_token()}}">
                         <input type="email" placeholder="Email" name="email" required="" pattern=".+@gmail.com" required="" autocomplete="off" >
							</div>
							<div class="styled-input">
								<input type="password" placeholder="Password" name="password" required="" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" required=""  >
							</div>
							<input type="submit" value="Sign In">
 <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>						</form>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<!-- //Modal content-->
		</div>
	</div>
	<!-- //Modal1 -->
	<!-- //signin Model -->
	<!-- signup Model -->
	<!-- Modal2 -->
	<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body modal-body-sub_agile">
					<div class="main-mailposi">
						<span class="fa fa-envelope-o" aria-hidden="true"></span>
					</div>
					<div class="modal_body_left modal_body_left1">
						<h3 class="agileinfo_sign">Sign Up</h3>
						<p>
							Come join the Green Life! Let's set up your Account.
						</p>
						<form action="registerme" method="post">
							<div class="styled-input agile-styled-input-top">
                         <input type="hidden" name="_token" value="{{csrf_token()}}">
    
			<font color="#33CC00" >FirstName</font><input type="text"  name="fname"  required=""autocomplete="nope" pattern="[a-zA-Z]+$" title="Give Valid  Name." >
                                
							</div>
                            <div class="styled-input">
								<font color="#33CC00" >LastName</font><input type="text"  name="lname" required=""autocomplete="nope" pattern="[A-Za-z]+" title="Give Valid  Name.">
							</div>
							<div class="styled-input">
								<font color="#33CC00" >HouseName</font><input type="text"  name="hname" required=""autocomplete="nope" pattern="[A-Za-z]+" title="Give Valid  Name.">
							</div>
                            <div class="styled-input">
                           <font color="#33CC00" >District</font><br>
                           <select id="district" name="district" required="">
                            <option value="0" >--select district--</option>
                            @isset($data)
                            @foreach($data as $district)
                            <option value="{{$district->district_id}}">{{$district->name}}</option>
                            @endforeach
                            @endisset
                            </select>
                            
                            </div><input type="text">
                            <div class="styled-input">

                            <font color="#33CC00" >City</font><br><select id="city" name="city"required="" >
                            <option disabled selected value>--select city--</option>
                            
                            </select>
                            
                            </div>
                            <input type="text">
                            <div class="styled-input">
								<font color="#33CC00" >Pincode</font><input type="text"  name="pincode" required=""autocomplete="nope" pattern="^[6][789][0-9]{4}$"
						title="Pincode must be a valid 6 digit number" required="required">
							</div>
                            
							<!--<font color="#33CC00" >State</font><select name="state" class="styled-input">
                                    <option value="volvo">kerala</option>
                                    <option value="saab">thamilnadu</option>
                                   <option value="fiat">karnadaka</option>
                              </select>
                            </div><input type="text">-->
                            <div class="styled-input">
								<font color="#33CC00" >Mobile</font><input type="text" name="mobile"  required="" autocomplete="nope" pattern= "[789][0-9]{9}" autocomplete="off" placeholder="enter mobile no" title="Phone number with 7-9 and remaing 9 digit with 0-9">
							</div>
                            <div class="styled-input">
								<font color="#33CC00" >UserName</font><input type="email"  name="email" required="" pattern=".+@gmail.com" autocomplete="off" placeholder="example@gmal.com">
							</div>
                            
							<div class="styled-input">
								<font color="#33CC00" >Password</font><input type="password"  name="password" id="password1" required="" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" placeholder="Example@123">
							</div>
							<div class="styled-input">
								<font color="#33CC00" >ConfirmPassword</font><input type="password" name="confirmpassword" id="password2" required="">
							</div>
							<input type="submit" value="Sign Up">
						</form>
						<p>
							<a href="#">By clicking register, I agree to your terms</a>
						</p>
					</div>
				</div>
			</div>
			<!-- //Modal content-->
		</div>
	</div>
	<!-- //Modal2 -->
	<!-- //signup Model -->

	<!-- banner-text -->
	<div class="slider">
		<div class="callbacks_container">
			<ul class="rslides callbacks callbacks1" id="slider4">
				<li>
					<div class="w3layouts-banner-top banner">
						<div class="container">
							<div class="agileits-banner-info">
								<h3>Save The World</h3>
								<p>Save the trees
									<i class="fa fa-tree" aria-hidden="true"></i> they will save you</p>
								<!--<div class="video-pop-wthree">
									<a href="#small-dialog1" class="view play-icon popup-with-zoom-anim ">
										<i class="fa fa-play-circle" aria-hidden="true"></i>Watch Our Video</a>
									<div id="small-dialog1" class="mfp-hide w3ls_small_dialog wthree_pop">
										<iframe src="https://player.vimeo.com/video/19251347"></iframe>
									</div>
								</div>-->
								<div class="thim-click-to-bottom">
									<a href="#about" class="scroll">
										<i class="fa  fa-chevron-down"></i>
									</a>
								</div>

							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="w3layouts-banner-top banner-2">
						<div class="container">
							<div class="agileits-banner-info">
								<h3>Plant Trees Now</h3>
								<p>Save the trees
									<i class="fa fa-tree" aria-hidden="true"></i> they will save you</p>
								<!--<div class="video-pop-wthree">
									<a href="#small-dialog2" class="view play-icon popup-with-zoom-anim ">
										<i class="fa fa-play-circle" aria-hidden="true"></i>Watch Our Video</a>
									<div id="small-dialog2" class="mfp-hide w3ls_small_dialog wthree_pop">
										<iframe src="https://player.vimeo.com/video/19251347"></iframe>
									</div>
								</div>-->
								<div class="thim-click-to-bottom">
									<a href="#about" class="scroll">
										<i class="fa  fa-chevron-down"></i>
									</a>
								</div>
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="w3layouts-banner-top banner-3">
						<div class="container">
							<div class="agileits-banner-info">
								<h3>Save our Planet</h3>
								<p>Save the trees
									<i class="fa fa-tree" aria-hidden="true"></i> they will save you</p>
								<!--<div class="video-pop-wthree">
									<a href="#small-dialog3" class="view play-icon popup-with-zoom-anim ">
										<i class="fa fa-play-circle" aria-hidden="true"></i>Watch Our Video</a>
									<div id="small-dialog3" class="mfp-hide w3ls_small_dialog wthree_pop">
										<iframe src="https://player.vimeo.com/video/19251347"></iframe>
									</div>
								</div>-->
								<div class="thim-click-to-bottom">
									<a href="#about" class="scroll">
										<i class="fa  fa-chevron-down"></i>
									</a>
								</div>
							</div>
						</div>
					</div>
				</li>
			</ul>
		</div>
		<div class="clearfix"> </div>
		<!-- //banner-text -->
	</div>
	<!-- //banner -->

	<!-- about -->
	<div class="banner-bottom-w3l" id="about">
		<div class="container">
			<div class="title-div">
				<h3 class="tittle">
					<span>W</span>elcome
				</h3>
				<div class="tittle-style">
				</div>
				<p>Save Trees, Clean Environment, Healthy Thinking, Happy Life & Green Earth</p>
			</div>
			<div class="welcome-sub-wthree">
				<div class="col-md-5 banner_bottom_left">
					<h4>About
						<span>E-plants</span>
					</h4>
					<p>'E-plants' ia an online version of plants nursery which helps a particular user to order and buy the plants,fertilizer and pestiscides that are needed for you.</p>
					<p>And we provide lands in lease those who wnant them to start a new plants nursery.This online system is developed with the objective of making the system reliable, fast and more informative.</p>
					
				</div>
				<!-- Stats-->
				<div class="col-md-7 stats-info-agile">
					<div class="w3l-right-stats">
						
					</div>
				</div>
				<!-- //Stats -->
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //about -->

	<!-- video section -->
	<div class="video-w3l" data-vide-bg="video/3">
		<h5>Save Trees, Clean Environment, Healthy Thinking, Happy Life & Green Earth</h5>
		<a href="#small-dialog4" class="play-icon popup-with-zoom-anim ">
			<i class="fa fa-play-circle-o" aria-hidden="true"></i>
		</a>
		<div id="small-dialog4" class="mfp-hide w3ls_small_dialog wthree_pop">
			<iframe src="https://player.vimeo.com/video/19251347"></iframe>
		</div>
	</div>
	<!-- //video section -->

	<!-- services -->
	<div class="agileits-services" id="services">
		<div class="container">
			<div class="title-div">
				<h3 class="tittle">
					<span>S</span>ervices
				</h3>
				<div class="tittle-style">
				</div>
			</div>
			<div class="agileits-services-row">
				<div class="col-md-4 col-xs-6 agileits-services-grids">
					<div class="col-xs-3 wthree-ser">
						<i class="fa fa-tint" aria-hidden="true"></i>
					</div>
					<div class="col-xs-9 wthree-heading">
						<h4>Distribute Plants</h4>
					</h4>
					</div>
					<div class="clearfix"></div>
					<p>We distribute different types of variey palnts that are needed for you.</p>
				</div>
				<div class="col-md-4 col-xs-6 agileits-services-grids">
					<div class="col-xs-3 wthree-ser">
						<i class="fa fa-recycle" aria-hidden="true"></i>
					</div>
                    <div class="col-xs-9 wthree-heading">
						<h4>Distribute Fertilizer</h4>
					</h4>
					</div>
					<div class="clearfix"></div>
					<p>We distribute different types of fertilizer,it provide favorable growth conditions of your palnts.</p>
				</div>
				<div class="col-md-4 col-xs-6 agileits-services-grids">
					<div class="col-xs-3 wthree-ser">
						<i class="fa fa-recycle" aria-hidden="true"></i>
					</div>
					<!--<div class="col-xs-9 wthree-heading">
						<h4>Recycling</h4>
					</div>
					<div class="clearfix"></div>
					<p>Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut</p>
					<a href="#" data-toggle="modal" data-target="#myModal1" class="w3-buttons">Read More</a>
				</div>
				<div class="col-md-4 col-xs-6 agileits-services-grids">
					<div class="col-xs-3 wthree-ser">
						<i class="fa fa-tree" aria-hidden="true"></i>
					</div>-->
					<div class="col-xs-9 wthree-heading">
						<h4>Distribute Pesticides </h4>
					</div>
					<div class="clearfix"></div>
					<p>We distribute different types of pesticides,it provide favorable growth conditions of your palnts.   </p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="agileits-services-row-2">
				<div class="col-md-4 col-xs-6 agileits-services-grids">
					<div class="col-xs-3 wthree-ser">
						<i class="fa fa-envira" aria-hidden="true"></i>
					</div>
					<div class="col-xs-9 wthree-heading">
						<h4>Farming Tips</h4>
					</div>
					<div class="clearfix"></div>
					<p>We provide different farming tips,that will help you and increase your productivity</p>
				</div>
				<div class="col-md-4 col-xs-6 agileits-services-grids">
					<div class="col-xs-3 wthree-ser">
						<i class="fa fa-globe" aria-hidden="true"></i>
					</div>
					<div class="col-xs-9 wthree-heading">
						<h4>Land in Lease</h4>
					</div>
					<div class="clearfix"></div>
					<p>We provide you land in lease for your farming needs</p>
				</div>
				<div class="col-md-4 col-xs-6 agileits-services-grids">
					<div class="col-xs-3 wthree-ser">
						<i class="fa fa-pagelines" aria-hidden="true"></i>
					</div>
					<div class="col-xs-9 wthree-heading">
						<h4>Guarden Design</h4>
					</div>
					<div class="clearfix"></div>
					<p>excellent commercial landscape and gardening services which include landscaping architecture & landscape design,Garden designing and Plants nursery services. </p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //services -->

	<!-- team -->
	<div class="team" id="team">
		<div class="container">
			<div class="title-div">
				
				<div class="tittle-style">
				</div>
			</div>
			<div class="agileits-team-grids">
				<div class="col-sm-3 col-xs-6 agileits-team-grid">
					<div class="team-info">
						<div class="team-caption">
						
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //team -->

	<!-- experts section -->
	
	<!-- //experts section -->

	<!-- projects -->
	
	<!-- //projects -->

	<!-- testimonials -->
	
	<!-- //testimonials -->

	<!-- contact -->
	<div class="contact" id="contact">
		<div class="title-div">
			<h3 class="tittle">
				<span>C</span>ontact Us
			</h3>
			<div class="tittle-style">
			</div>
		</div>
		<div class="col-md-6 map">
		</div>
		<div class="col-md-6 contact_grids_info">
			<h5 class="small-title">Visit Us</h5>
			
	<!--<div class="second-contact-agile">
		<div class="col-md-6 form-bg">
			<form action="#" method="post">
				<div class="contact-fields">
					<input type="text" name="Name" placeholder="Name" required="">
				</div>
				<div class="contact-fields">
					<input type="email" name="Email" placeholder="Email" required="">
				</div>
				<div class="contact-fields">
					<input type="text" name="Subject" placeholder="Subject" required="">
				</div>
				<div class="contact-fields">
					<textarea name="Message" placeholder="Message" required=""></textarea>
				</div>
				<input type="submit" value="Submit">
			</form>
		</div>-->
		<div class="col-md-6 address-left-second">
			<div class="address-grid">
				<h5 class="small-title">Contact Info</h5>
				<div class="address-grids">
					<span class="fa fa-volume-control-phone" aria-hidden="true"></span>
					<div class="contact-right">
						<p>PhoneNumber </p>
						<span>+917558814170</span>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="address-grids">
					<span class="fa fa-envelope-o" aria-hidden="true"></span>
					<div class="contact-right">
						<p>Mail </p>
						<a href="mailto:info@example.com">eplants@gmail.com</a>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="address-grids">
					<span class="fa fa-map-marker" aria-hidden="true"></span>
					<div class="contact-right">
						<p>Location</p>
						<span>Kottayam,Kerala,Pin:670582</span>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="address-grids">
					<span class="fa fa-calendar" aria-hidden="true"></span>
					
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
	<!-- //contact -->

	<!-- footer -->
	<!--<div class="footer-bot">
		<div class="w3layouts-newsletter">
			<div class="w3ls-social-icons-2">
				<h3>Connect With Us On Social</h3>
				<a class="facebook" href="#">
					<i class="fa fa-facebook"></i>
				</a>
				<a class="twitter" href="#">
					<i class="fa fa-twitter"></i>
				</a>
				<a class="pinterest" href="#">
					<i class="fa fa-google-plus"></i>
				</a>
				<a class="linkedin" href="#">
					<i class="fa fa-linkedin"></i>
				</a>
			</div>
			<div class="col-md-7 agileinfo-newsletter">
				<h3>
					<i class="fa fa-envelope" aria-hidden="true"></i>Join our Newsletter</h3>
				<form action="#" method="post">
					<input type="email" placeholder="Enter Your Email" name="email" required="">
					<input type="submit" value="Subscribe">
				</form>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="container">
			<div class="col-xs-3 logo2">
				<h2>
					<a href="index.html">
						<span>G</span>reen
						<span>L</span>ife</a>
				</h2>
			</div>
			<div class="col-xs-9 ftr-menu">
				<ul>
					<li>
						<a href="index.html">Home</a>
					</li>
					<li>
						<a class="scroll" href="#about">About</a>
					</li>
					<li>
						<a class="scroll" href="#services">Services</a>
					</li>
					<li>
						<a class="scroll" href="#team">Team</a>
					</li>
					<li>
						<a class="scroll" href="#projects">Projects</a>
					</li>
					<li>
						<a class="scroll" href="#contact">Contact Us</a>
					</li>
				</ul>
			</div>
			<div class="clearfix"></div>
			<div class="copy-right">
				<p> &copy; 2018 Green Life. All Rights Reserved | Design by
					<a href="http://w3layouts.com/"> W3layouts</a>
				</p>
			</div>-->
		</div>
	</div>
	<!-- //footer -->


	<!-- js-scripts -->

	<!-- jquery -->
	<script src="js/jquery-2.1.4.min.js"></script>
	<!-- //jquery -->

	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->

	<!--  light box js -->
	<script src="js/lightbox-plus-jquery.min.js"></script>
	<!-- //light box js-->
	
	<!-- stats numscroller-js-file -->
	<script src="js/numscroller-1.0.js"></script>
	<!-- //stats numscroller-js-file -->
	
	<!-- Baneer-js -->
	<script src="js/responsiveslides.min.js"></script>
	<script>
		// You can also use "$(window).load(function() {"
		$(function () {
			// Slideshow 4
			$("#slider4").responsiveSlides({
				auto: true,
				pager: true,
				nav: false,
				speed: 500,
				namespace: "callbacks",
				before: function () {
					$('.events').append("<li>before event fired.</li>");
				},
				after: function () {
					$('.events').append("<li>after event fired.</li>");
				}
			});

		});
	</script>
	<!-- //Baneer-js -->

	<!-- navigation -->
	<script>
		(function ($) {
			// Menu Functions
			$(document).ready(function () {
				$('#menuToggle').click(function (e) {
					var $parent = $(this).parent('.menu');
					$parent.toggleClass("open");
					var navState = $parent.hasClass('open') ? "hide" : "show";
					$(this).attr("title", navState + " navigation");
					// Set the timeout to the animation length in the CSS.
					setTimeout(function () {
						console.log("timeout set");
						$('#menuToggle > span').toggleClass("navClosed").toggleClass("navOpen");
					}, 200);
					e.preventDefault();
				});
			});
		})(jQuery);
	</script>
	<!-- //navigation -->

	<!-- pop-up(for video popup)-->
	<script src="js/jquery.magnific-popup.js"></script>
	<script>
		$(document).ready(function () {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});

		});
	</script>
	<!-- //pop-up-box (syllabus section video)-->
	
	<!-- video js (background) -->
	<script src="js/jquery.vide.min.js"></script>
	<!-- //video js (background) -->

	<!-- smoothscroll -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smoothscroll -->

	<!-- password-script -->
	<script>
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}

		function validatePassword() {
			var pass2 = document.getElementById("password2").value;
			var pass1 = document.getElementById("password1").value;
			if (pass1 != pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');
			//empty string means no validation error
		}
	</script>
	<!-- //password-script -->

	<!-- start-smooth-scrolling -->
	<script src="js/move-top.js"></script>
	<script src="js/easing.js"></script>
	<script>
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
    <script src="js/ajaxx.js"></script>
	<!-- //end-smooth-scrolling -->

	<!-- smooth scrolling-bottom-to-top -->
	<script>
		$(document).ready(function () {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
			$().UItoTop({
				easingType: 'easeOutQuart'
			});
		});
	</script>
	<a href="#" id="toTop" style="display: block;">
		<span id="toTopHover" style="opacity: 1;"> </span>
	</a>
	<!-- //smooth scrolling-bottom-to-top -->

	<!-- flexSlider (for testimonials) -->
	<script defer src="js/jquery.flexslider.js"></script>
	<script>
		$(window).load(function () {
			$('.flexslider').flexslider({
				animation: "slide",
				start: function (slider) {
					$('body').removeClass('loading');
				}
			});
		});
	</script>
	<!-- //flexSlider (for testimonials) -->

	<!-- //js-scripts -->

</body>

</html>