
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>E-plants</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="admin/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="admin/vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="admin/vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="admin/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="admin/images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
        <a class="navbar-brand brand-logo" href="index.php">        </a>
        <a class="navbar-brand brand-logo-mini" href="index.php">
          <img src="admin/images/logo-mini.svg" alt="logo" />        </a>      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center">
        <ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
          <li class="nav-item">
              <span class="badge badge-primary ml-1"></span>            </a>          </li>
          <li class="nav-item active">
            <a href="#" class="nav-link">
          <li class="nav-item">
            <a href="#" class="nav-link">
        </ul>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item dropdown">
              <i class="mdi mdi-file-document-box"></i>
              <div class="dropdown-item">
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                <div class="preview-item-content flex-grow">
                   </h6>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                <div class="preview-item-content flex-grow">
                                   </h6>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                <div class="preview-item-content flex-grow">
                                   </h6>
                  <p class="font-weight-light small-text">
                </div>
              </a>            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <a class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">      </p>
                <span class="badge badge-pill badge-warning float-right"></span>              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-success">
                    <i class="mdi mdi-alert-circle-outline mx-0"></i>                  </div>
                </div>
                
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="mdi mdi-comment-text-outline mx-0"></i>                  </div>
                </div>

              </a>
                
              </a>            </div>
          </li>
          <li class="nav-item dropdown d-none d-xl-inline-block">
            <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <span class="profile-text">Hello, Admin !</span>
             <img class="img-xs rounded-circle" src="admin/images/faces-clipart/pic-1.png" alt="Profile image">
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
              <a class="dropdown-item p-0">
                <div class="d-flex border-bottom">
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center">
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center border-left border-right">
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center">
                </div>
             
              <a href="/logout" class="dropdown-item">
                Sign Out              </a>            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="user-wrapper">
                <div class="profile-image">
                  <img src="admin/images/faces-clipart/pic-1.png" alt="profile image">
                </div>
                <div class="text-wrapper">
                  <p class="profile-name">Admin</p>
                  <div>
                    <small class="designation text-muted"></small>
                    <span class="status-indicator online"></span>
                  </div>
                </div>
              </div>
              
            </div>
          </li>
          
        <!--<li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
              <i class="menu-icon mdi mdi-content-copy"></i>
              <span class="menu-title">Add Products</span>
             <!-- <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                  <a class="nav-link" href="pages/ui-features/buttons.html">Buttons</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="pages/ui-features/typography.html">Typography</a>
                </li>
              </ul>
            </div>
          </li>-->
        
         <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
              <i class="menu-icon mdi mdi-restart"></i>
              <span class="menu-title">Add Products</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="auth">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                  <a class="nav-link" href="addplant"> Add Plants </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="pages/samples/login.html"> Add Pesticides </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="pages/samples/register.html"> Add Fertilizer </a>
                </li>
                
              </ul>
            </div>
          </li>
        
          <li class="nav-item">
            <a class="nav-link" href="viewuser">
              <i class="menu-icon mdi mdi-chart-line"></i>
              <span class="menu-title">ViewUsersS</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="vieworders.php">
              <i class="menu-icon mdi mdi-table"></i>
              <span class="menu-title">ViewOrders</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="viewfeedback.php">
              <i class="menu-icon mdi mdi-sticker"></i>
              <span class="menu-title">ViewFeedbcak</span>
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link" href="viewplant">
              <i class="menu-icon mdi mdi-sticker"></i>
              <span class="menu-title">ViewAddedPlants</span>
            </a>
          </li>
         
         
        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row purchace-popup">
            <div class="col-12">
            <font color="#000000"><i><u>Add Plants Now!!</u></i></font>
              <span class="d-block d-md-flex align-items-center">
               <!-- <p>Like what you see? Check out our premium version for more.</p>-->
                <!--<a class="btn ml-auto download-button d-none d-md-block" href="https://github.com/BootstrapDash/StarAdmin-Free-Bootstrap-Admin-Template" target="_blank">Download Free Version</a>-->
               <!-- <a class="btn purchase-button mt-4 mt-md-0" href="https://www.bootstrapdash.com/product/star-admin-pro/" target="_blank">Upgrade To Pro</a>-->
                </i>              </span>            </div>
          </div>
          <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body"><font size="-1" color="#00FF00"></font>
                  <p class="card-description">
                    
                  </p>
                <form action="/addplant" method="post" enctype="multipart/form-data" class="form-sample">
                        {{ csrf_field() }}

                
			       <h4 class="card-title">Plant Name</h4><input name="plantname" type="text"  required="" pattern="[a-zA-Z]+$" title="Give Valid  Name." placeholder="productname" class="form-control" autocomplete="off"> 
				
                            
				<h4 class="card-title">Category</h4> 
               
                     <select class="form-control" name="category" id="type" required="">
                      <option value="0" >--select--</option>

                    @foreach($type as $category)
                    <option value={{$category->catid}}> {{$category->name}}</option>
                     @endforeach
                    </select>
                    
                     
                       <h4 class="card-title">Image</h4></font><input type="file" name= "plantimage" required="" class="form-control" accept=".png,.jpg,.jpeg.JPG" required=""/>
          	
<h4 class="card-title">Description</h4></font> <input name="plantdescription" type="text" required=""  placeholder="product description" class="form-control"  required="" autocomplete="off" pattern="[a-zA-Z]+$" title="Give Valid  Description."/>
          	
<!--<h4 class="card-title">Quantity</h4></font> <input name="plantquantity" type="text" required=""  placeholder="product quantity" class="form-control"  required="" autocomplete="off" pattern = "[1-9]{1,4}"/>   -->
   
<h4 class="card-title">Price</h4></font> 
<p>
  <input name="price" type="number" min="100" max="90000" placeholder="price" class="form-control" required=""   autocomplete="off"/>
 </p>
 <h4 class="card-title">expiry</h4></font> 
<p>
  <input name="expiry" type="date"  class="form-control" required=""/>
 </p>
  <h4 class="card-title">stock</h4></font>
<p>
  <input name="stock" type="number" required=""  placeholder="product quantity" class="form-control" autocomplete="off" min="1" max="100"/>
 </p>

<p>&nbsp;</p>
<!--<button class="btn btn-success btn-block">ADD 

              </button>-->
              <button type="submit" class="btn btn-success mr-2">Add</button>
            

<!--<input name="btn" type="submit" value="ADD" class="bt/>
                        <button type="button" class="btn btn-success btn-fw">Success</button>-->

 

</form>  
          
          
          
          
          
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
           <!-- <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with
              <i class="mdi mdi-heart text-danger"></i>
            </span>-->
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="admin/vendors/js/vendor.bundle.base.js"></script>
  <script src="admin/vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>
