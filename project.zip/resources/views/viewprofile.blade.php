 <table width="500" height="116" class="table table-striped">
                      <thead>
                        <tr>
                          <th width="143">
                            fName                          </th>
                          <th width="133">
                            lname                         </th>
                          <th width="46">
                            housename                         </th>
                          <th width="163">
                            pincode                          </th>
                          <th width="128">
                            mob                          </th>
                          <th width="82">
                            email                          </th>
                        </tr>
                        @foreach($items as $row)

                      </thead>
                      <tbody>
                        <tr>
                          <td class="py-1">
							{{$row['fname']}}                            </td>
                          <td>
                            {{ $row['lname'] }}                          </td>
                          <td>{{ $row['hname'] }}</td>
                          <td>
                           {{ $row['pincode']}}                          </td>
                          <td>
                           {{ $row['mobile'] }}                          </td>
                          <td>
                          {{ $row['username'] }}                          </td>
                         <!-- <td width="36"><a href='delete/{{$row->id}}'>delete</a></td>-->

			<!--<td width="22"><a href='edit/{{$row->id}}'>edit</a></td>-->

                        </tr>
                        @endforeach
                      </tbody>
                    </table>
