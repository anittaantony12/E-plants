 <table width="500" height="116" class="table table-striped">
                      <thead>
                        <tr>
                          <th width="143">
                            Name                          </th>
                         <!-- <th width="133">
                            Category                          </th>-->
                          <th width="46">
                            Image                          </th>
                          <th width="163">
                            Description                          </th>
                          <th width="128">
                            price</th>
                          <th width="82">
                            expiry                          </th>
                              <th width="128">
                            stock</th>
                        </tr>
                        @foreach($addplant as $row)

                      </thead>
                      <tbody>
                        <tr>
                          <td class="py-1">
							{{$row['plantname']}}                            </td>
                         <!-- <td>
                          {{$row['name']}}
                          </td>-->
                          <td><img src="storage/upload/{{$row->plantimage}}" width="54" height="56" ></td>
                          <td>
                           {{ $row['plantdescription']}}                          </td>
                          <td>
                           {{ $row['price'] }}                          </td>
                          <td>
                          {{ $row['expiry'] }}                          </td>
                          <td>
                          {{ $row['stock'] }}                          </td>
                         <!-- <td width="36"><a href='delete/{{$row->id}}'>delete</a></td>-->
                         <?php $id=$row->id;?>
                         <td>  <label class="badge badge-success"><a href='delete/{{$row->id}}'>Delete</a></label></td>

			<td width="22"><label class="badge badge-success"><a href="{{route('profile_edit',['id'=>$id])}}">edit</a></td>
             <td>                           <!--  <label class="badge badge-warning"><a href='edit/{{$row->id}}'>Edit</a></label>-->
</td>
                        </tr>
                        @endforeach
                      </tbody>
                    </table>