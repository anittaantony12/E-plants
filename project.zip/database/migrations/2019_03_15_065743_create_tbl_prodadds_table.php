<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblProdaddsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_prodadds', function (Blueprint $table) {
            $table->bigIncrements('id');
			$table->bigInteger('catid')->unsigned();
            $table->foreign('catid')->references('catid')->on('tbl_categories')->onDelete('cascade');
            $table->String('plantname');
            $table->String('plantimage');
            $table->String('plantdescription');
            $table->String('price');
            $table->String('expiry');
            $table->String('stock');
            $table->String('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_prodadds');
    }
}
