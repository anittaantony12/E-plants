<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRegistrationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registrations', function (Blueprint $table) {
            $table->bigIncrements('regid');
			$table->string('fname');
			$table->string('lname');
			$table->string('hname');
			$table->string('district');
			$table->string('city');
			$table->string('pincode');
			
			$table->string('mobile');
			$table->string('email');
			$table->string('password');
			//$table->string('confirmpassword');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('registrations');
    }
}
