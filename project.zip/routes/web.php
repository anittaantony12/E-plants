<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/welcome', function () {
    return view('welcome');
});
Route::get('/managerhome', function () {
    return view('managerhome');
});
Route::get('/plant', function () {
    return view('plant');
});
Route::get('/viewplant', function () {
    return view('viewplant');
});

//Route::get('/plantss', function () {
//    return view('plantss');
//});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::any('/loginme', 'LoginController@login')->name('home');
Route::post('/registerme', 'RegistrationController@registration')->name('home');
Route::resource('/registerme', 'RegistrationController');
//ost('/plant', 'PlantController@plant')->name('home');
Route::post('/plants', 'PlantController@storefile'); 
Route::get('/viewplant', 'PlantController@index'); 
Route::get('delete/{id}', 'PlantController@destroy'); 
Route::get('edit/{id}', 'PlantController@edit')->name('plant.edit');
Route::post('/plant/update/{id}', 'PlantController@update')->name('plant.update');
Route::get('/logout','\App\Http\Controllers\LoginController@logout');
Route::get('/viewuser', 'RegistrationController@index'); 

//Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');

//Route::resource('/addplant', 'PlantController');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
