<?php

namespace App\Http\Controllers;

use App\Add;
use Illuminate\Http\Request;
use DB;
class AddController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      /* $name=$request->input('plantname');
	   $check=DB::table('adds')->where(['plantname'=>$name])->get();
	if(count($check)==0)
	{
        $add=new Add([
           'plantname'=>$request->get('plantname'),
		    'plantcategory'=>$request->get('plantcategory')]);
			 $result=DB::insert("insert into adds(plantname,plantcategory)values(?,?)");
	 // return view('about');
	 echo"sucess";
    }
    else
	{
   echo"not sucess";
   	}*/
    
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Add  $add
     * @return \Illuminate\Http\Response
     */
    public function show(Add $add)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Add  $add
     * @return \Illuminate\Http\Response
     */
    public function edit(Add $add)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Add  $add
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Add $add)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Add  $add
     * @return \Illuminate\Http\Response
     */
    public function destroy(Add $add)
    {
        //
    }
}
