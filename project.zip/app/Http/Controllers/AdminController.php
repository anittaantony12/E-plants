<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\tbl_prodadd;


class AdminController extends Controller
{
   	public function userviewplant()
    {
        $demo=tbl_prodadd::all();
        //return $demo;
        return view ('adview',compact('demo'));
    }
}
