<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\tbl_prodadd;

class AddPlantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        {
            $addplant = tbl_prodadd::all();

            return view ('viewplant',compact('addplant'));
        }
		
		
	 /**	$request->session()->put('id',$id);
		 return view ('viewplant');*/

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
 $name = $request->input('plantname');
        $image = $request->file('plantimage');

		$filename= $request->plantimage->getClientOriginalName();
		
       $request->plantimage->storeAs('public/upload',$filename);
   
       $description = $request->input('plantdescription');
    $price = $request->input('price');
    $expiry = $request->input('expiry');
    $stock = $request->input('stock');
	$status_id=2;
    
    //$u_type=$request->get('u_type');
    $catid=DB::table('tbl_categories')->max('catid');
  $data=array('catid'=>$catid,"plantname"=>$name,"plantimage"=>$filename,"plantdescription"=>$description,"price"=>$price,"expiry"=>$expiry,"stock"=>$stock,"status"=>$status_id);
DB::table('tbl_prodadds')->insert($data);
echo "Record inserted successfully.<br/>";
if(count($data)>0)
{
    return redirect('/viewplant');
}    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
		$request->session()->put('id',$id);
		$edit=DB::table('tbl_prodadds')->where('id',$id);
		return view('editplant',compact($edit));
     //$addplant=tbl_prodadd::find($id);
	 //return view("editplant",compact('addplant'.id));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
	
	
	
		$plantid=$request->input('plantid');
		$catid=$request->input('categoryid');
		$plantname=$request->input('plantname');
		
		
		//$plantimage=$request->input('plantimage');
		// $image = $request->file('image');
		 
		$filename= $request->image->getClientOriginalName();
		
       $request->image->storeAs('public/upload',$filename);
		$plantdesc=$request->input('plantdescription');
		$price=$request->input('price');
		$expiry=$request->input('expiry');
		$stock=$request->input('stock');
		$name=$request->input('name');
		
		
		DB::table('tbl_prodadds')->where('id',$plantid)->update(['plantname'=>$plantname,'plantimage'=>$filename,'plantdescription'=>$plantdesc,'price'=>$price,'expiry'=>$expiry,'stock'=>$stock]);
		DB::table('tbl_categories')->where('catid',$catid)->update(['name'=>$name]);
    	return redirect('/viewplant');
		//return view('viewplant');;
	//echo"success";
	
			//$this->validate($request, [
           // 'plantname' => 'required',
           //// 'plantcategory' => 'required',
		   //'plantimage' => 'required',
            //'plantdescription' => 'required',
           // 'plantquantity' => 'required',
            //'price' => 'required',
			//  'expiry' => 'required',

           // 'stock' => 'required'

        //]);
        }
        //get post data
         //$addplant = tbl_proadd::fing($plantname);
         //$addplant->plantname=$request->get('plantname');
		 //$addplant->plantimage=$request->get('plantimage');
		 //$addplant->plantdescription=$request->get('plantdescription');
		 //$addplant->price=$request->get('price');
		 //		 $addplant->expiry=$request->get('expiry');

		 //addplant->stock=$request->get('stock');

		 //$addplant>save();
//return redirect()->route('viewplnat')->with('sucess','data updated');
        //update post data
        
        //store status message
       // Session::flash('success_msg', 'Plant updated successfully!');

//}
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
	public function userviewplant()
    {
        $demo=tbl_prodadd::all();
        //return $demo;
        return view ('userviewplant',compact('demo'));
    }
	
	
    public function destroy($id)
    {
         DB::delete('delete from tbl_prodadds where id=?',[$id]);
		return redirect("viewplant");
    }
}
