<?php

namespace App\Http\Controllers;

use App\Registration;
use Illuminate\Http\Request;
use DB;

class RegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         {
            $registration = Registration::all();
            return view ('viewuser',compact('registration'));
        }
    }
	
	/*public function registration(Request $request)
	{
      $fname=$request->input('fname');
	  $lname=$request->input('lname');
	  $hname=$request->input('hname');
	  $pin=$request->input('pincode');
	   $mobile=$request->input('mobile');
	   $username=$request->input('username');
	   $pwd=$request->input('password');
	  $conpwd=$request->input('confirmpassword');
	  //echo $unm;
	  $check=DB::table('registrations')->where(['fname'=>$fname,'lname'=>$lname,'hname'=>$hname,'pincode'=>$pin,'mobile'=>$mobile,'username'=>$username,'password'=>$pwd,'confirmpassword'=>$conpwd])->get();
	  if(count($check)>0)
	  {
		  echo "sucess";
      }
	else
	{
		echo "no sucess";
	}
	}


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
	
	$email=$request->input('email');
	$check=DB::table('registrations')->where(['email'=>$email])->get();
	if(count($check)==0)
	{
        $Registration=new Registration([
           'fname'=>$request->get('fname'),
		    'lname'=>$request->get('lname'),

           'hname'=>$request->get('hname'),
		    'district'=>$request->get('district'),

           'city'=>$request->get('city'),
           'pincode'=>$request->get('pincode'),



           'mobile'=>$request->get('mobile'),

           'email'=>$request->get('email'),
           'password'=>$request->get('password'),

          // 'confirmpassword'=>$request->get('confirmpassword')
       ]);
       $Registration->save();
	         $email=$request->input('email');
	  $pwd=$request->input('password');
	  $result=DB::insert("insert into logins(email,password,status)values(?,?,?)",[$email,$pwd,1]);
	   return view('welcome');
	// echo"sucess";
    }
    else
	{
   echo"username already exist!!";
   	}
}

	 public function profile(Request $request)
    {		
	
	$email = $request->get('email');
		$items = DB::table('registrations')->where(['email'=>$email])->get();
        return view('viewprofile',compact('items'));
		
		
		
       
		
		
    }
	 


    /**
     * Display the specified resource.
     *
     * @param  \App\Registration  $registration
     * @return \Illuminate\Http\Response
     */
    public function show(Registration $registration)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Registration  $registration
     * @return \Illuminate\Http\Response
     */

	 
	 
	 
	 
	 
    public function edit(Registration $registration)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Registration  $registration
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Registration $registration)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Registration  $registration
     * @return \Illuminate\Http\Response
     */
    public function destroy(Registration $registration)
    {
        //
    }
}
