<?php

namespace App\Http\Controllers;

use App\Login;
use Illuminate\Http\Request;
use DB;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
	public function login(Request $request)
	{
      $name=$request->input('username');
	  $pwd=$request->input('password');
	  //echo $unm;
	 $check=DB::table('logins')->where(['username'=>$name,'password'=>$pwd])->get();
	 $checkLogin1=DB::table('logins')->where(['username'=>$name,'password'=>$pwd,'status'=>0])->get();
	 $checkLogin2=DB::table('logins')->where(['username'=>$name,'password'=>$pwd,'status'=>1])->get();
	 $checkLogin3=DB::table('logins')->where(['username'=>$name,'password'=>$pwd,'status'=>2])->get();
        if(count($checkLogin1)>0)
		{
		session_start();
		$request->session()->put('name', $name);
		return view("adminhome");
		}
        elseif(count($checkLogin2)>0)
		{
		session_start();
		$request->session()->put('name', $name);
		//echo "sucess111";
		return view("userhome");
		}		
         elseif(count($checkLogin3)>0)
		{
		session_start();
		$request->session()->put('name', $name);
		return view("managerhome");
		}		
		else
		{
		//echo "not";
		return view("welcome");
		}
		}
	 /* if(count($check)>0)
	  {
		  echo "sucess";
      }
	else
	{
		echo "no sucess";
	}
	}*/

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function show(Login $login)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function edit(Login $login)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Login $login)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function destroy(Login $login)
    {
        //
    }
	public function logout(Request $request)
	{
	session_start();
	session_destroy();
	session()->flush();
	return redirect('/loginme');
	}
}
