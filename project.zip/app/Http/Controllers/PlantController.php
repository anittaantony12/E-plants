<?php

namespace App\Http\Controllers;

use App\Plant;
use Illuminate\Http\Request;
use DB;
use App\tbl_category;

class PlantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        {
            $plant = Plant::all();
            return view ('viewplant',compact('plant'));
        }
        
        //return view('viewdoctor');
    }
	public function index2()
	{
	$type1=tbl_category::all();
	 return view ('managerhome',compact('type1'));
	}
	

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storefile(Request $request)
    {
	 $name = $request->input('plantname');
    $image = $request->file('plantimage');

    
        $filename= $request->plantimage->getClientOriginalName();
        //Storage::put('public\upload\',$filename,file_get_contents($request->file('photo')->getRealPath()));
       $request->plantimage->storeAs('public/upload',$filename);
    $description = $request->input('plantdescription');
    $price = $request->input('price');
    $expiry = $request->input('expiry');
    $stock = $request->input('stock');
    $status_id=2;
    
    //$u_type=$request->get('u_type');
    $catid=DB::table('tbl_categories')->max('id');
   // $brand_id=DB::table('tbl_addbrand')->max('brand_id');
      $data=array('catid'=>$catid,"plantname"=>$name,"plantimage"=>$image,"plantdescription"=>$description,"price"=>$price,"expiry"=>$expiry,    "stock"=>$stock,"status"=>$status_id);
DB::table('tbl_prodadds')->insert($data);
echo "Record inserted successfully.<br/>";
if(count($data)>0)
{
    return view('plant');
}
//$reg_id=DB::table('tbl_register')->max('reg_id');
//$data1=array('reg_id'=>$reg_id,"email"=>$email,"password"=>$password,"u_status"=>$u_status,"u_type"=>$u_type);
//DB::table('tbl_login')->insert($data1);
//echo "Record inserted successfully.<br/>";
//return redirect('/index');
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
     /*$name=$request->input('plantname');
	$filename6=$request->plantimage->getClientOriginalName();
	$request->plantimage->storeAs('public/upload',$filename6);
	$check=DB::table('plants')->where(['plantname'=>$name])->get();
	
	if(count($check)==0)
	{
          $plant=new Plant([
           'plantname'=>$request->get('plantname'),
		    'plantcategory'=>$request->get('plantcategory'),

           'plantimage'=>$filename6,

           'plantdescription'=>$request->get('plantdescription'),

           'plantquantity'=>$request->get('plantquantity'),

           'price'=>$request->get('price')
      
    ]);
	
       $plant->save();
	   $plant = Plant::all();
       return view ('viewplant',compact('plant'));
	   return view("viewplant");
	    //$name=$request->input('plantname');
       //$result=DB::insert("insert into plants(plantname,plantcategory,plantimage,plantdescription,plantquantity,price)values(?,?,?,?,?,?)"); 
//echo"sucess";
    }
    else
	{
   echo"not sucess";
   	}    
  }/*

    /**
     * Display the specified resource.
     *
     * @param  \App\Plant  $plant
     * @return \Illuminate\Http\Response
     */
    public function show(Plant $plant)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Plant  $plant
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
          $plant = Plant::find($id);
        return view("edit", ['plant' => $plant]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Plant  $plant
     * @return \Illuminate\Http\Response
     */
    public function update($id,Request $request)
    {     
	   $this->validate($request, [
            'plantname' => 'required',
            'plantcategory' => 'required',
		     //'plantimage' => 'required',
            'plantdescription' => 'required',
            'plantquantity' => 'required',
            'price' => 'required'

        ]);
        
        //get post data
        $plantData = $request->all();
        
        //update post data
        Plant::find($id)->update($plantData);
        
        //store status message
       // Session::flash('success_msg', 'Plant updated successfully!');

        return redirect("viewplant");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Plant  $plant
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::delete('delete from plants where id=?',[$id]);
		return redirect("viewplant");
    }
	public function logout()
	{
	session()->flush();
	return redirect("/loginme");
	}
}
