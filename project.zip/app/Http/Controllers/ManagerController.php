<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\tbl_category;

class ManagerController extends Controller
{
   public function addproduct()
   {
   $type=tbl_category::all();
   return view ('plant',compact('type'));
   }
}
