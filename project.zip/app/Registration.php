<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Registration extends Model
{
     public $fillable=['fname','lname','hname','district','city','pincode','mobile','email','password','status'];
}
