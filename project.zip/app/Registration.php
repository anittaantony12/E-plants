<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Registration extends Model
{
     public $fillable=['fname','lname','hname','pincode','mobile','username','password','status'];
}
