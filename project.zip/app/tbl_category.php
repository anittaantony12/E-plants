<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_category extends Model
{
    //
}
