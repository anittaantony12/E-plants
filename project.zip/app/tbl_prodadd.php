<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_prodadd extends Model
{
    protected $table="tbl_prodadds";
    protected $primaryKey = 'id';
	// public $primaryKey = 'reg_id';
    protected $fillable = [
        'plantname','category','plantimage','plantdescription','price','expiry','stock',
    ];
}
